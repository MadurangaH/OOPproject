package com.mvc.bean;

abstract class commonUser {
	
	abstract public void validateUser();

}
