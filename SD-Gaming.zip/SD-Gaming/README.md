# SD- Online Gaming Web Application

This project is done by using Java , MySQL , HTML , CSS , Bootstrap and Java Script .

This is done by me for my year 2 Semester 1 project which is Online gaming website. According to the mvc architecture, All 4 CRUD operations are done here.

Tools used for this project :- Eclipse IDE (JDK 8) , Xampp , Tomcat
